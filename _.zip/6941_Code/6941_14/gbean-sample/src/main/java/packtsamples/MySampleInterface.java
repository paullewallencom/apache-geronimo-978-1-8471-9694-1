package packtsamples;

public interface MySampleInterface {
	String myMethod1();
}
