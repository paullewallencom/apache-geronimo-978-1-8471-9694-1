package com.packtpub.library.ejb;


public interface MailBusinessLocal {
	public void sendMail();
}
