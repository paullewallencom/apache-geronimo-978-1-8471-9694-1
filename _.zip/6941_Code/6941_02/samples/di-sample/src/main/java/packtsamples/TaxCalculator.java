package packtsamples;

public interface TaxCalculator{
    public float calculateTax(float amount);
}
