package packtsamples.di;

public interface TaxCalculator{
    public float calculateTax(float amount);
}
